//Reload the Game
function reload() {
    location.reload()
    alert("GAME RELOADED!")
}

//Intro Text
const intro = document.getElementById("intro");
console.log(intro);
intro.innerHTML = "<p>This game is simple. Just place the mouse-over a square to play your turn. It will randomly play an X or O.<br> The first to match 3 lined-up X or O wins the game!</p>";


function play1() {
    document.getElementById('play1').innerHTML = 'X';
}





